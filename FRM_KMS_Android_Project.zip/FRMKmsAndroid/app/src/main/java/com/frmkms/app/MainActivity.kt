package com.frmkms.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

data class Stop(val lat: Double, val lon: Double, val note: String, val time: Long)

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private val stops = mutableListOf<Stop>()
    private val requestCode = 42
    private val prefs by lazy { getSharedPreferences("frm_kms_data", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContentView(R.layout.activity_main)
        map = findViewById(R.id.map)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(12.0)
        map.controller.setCenter(GeoPoint(12.9716, 77.5946))
        loadStops()
        redraw()
        findViewById<Button>(R.id.markButton).setOnClickListener { askCommentThenLocate() }
        findViewById<Button>(R.id.reportButton).setOnClickListener { showDailyReport() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showHistory() }
        updateStats()
    }

    private fun askCommentThenLocate() {
        val input = EditText(this).apply { hint = "Comment (e.g. customer visit, office)" }
        AlertDialog.Builder(this).setTitle("Mark this location")
            .setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save location") { _, _ -> getCurrentLocation(input.text.toString().trim()) }
            .show()
    }

    private fun getCurrentLocation(note: String) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            Toast.makeText(this, "Allow location, then tap Mark location again.", Toast.LENGTH_LONG).show()
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (provider in providers) {
            try {
                val loc = lm.getLastKnownLocation(provider)
                if (loc != null && (best == null || loc.accuracy < best!!.accuracy)) best = loc
            } catch (_: SecurityException) {}
        }
        if (best != null && System.currentTimeMillis() - best!!.time < 120_000) {
            addStop(best!!.latitude, best!!.longitude, note)
        } else {
            Toast.makeText(this, "GPS fix not ready. Turn on Location and try again outdoors.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addStop(lat: Double, lon: Double, note: String) {
        stops.add(Stop(lat, lon, note, System.currentTimeMillis()))
        saveStops()
        redraw()
        map.controller.animateTo(GeoPoint(lat, lon))
        updateStats()
        Toast.makeText(this, "Location saved and connected to your previous mark.", Toast.LENGTH_SHORT).show()
    }

    private fun redraw() {
        map.overlays.clear()
        val line = Polyline()
        line.outlinePaint.color = android.graphics.Color.rgb(215, 25, 32)
        line.outlinePaint.strokeWidth = 8f
        stops.forEachIndexed { index, stop ->
            val point = GeoPoint(stop.lat, stop.lon)
            line.addPoint(point)
            val marker = Marker(map).apply {
                position = point
                title = if (stop.note.isBlank()) "Stop ${index + 1}" else stop.note
                snippet = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(stop.time))
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            }
            map.overlays.add(marker)
        }
        if (stops.size > 1) map.overlays.add(0, line)
        map.invalidate()
    }

    private fun updateStats() {
        val today = dayKey(System.currentTimeMillis())
        val todays = stops.filter { dayKey(it.time) == today }
        findViewById<TextView>(R.id.countText).text = todays.size.toString()
        findViewById<TextView>(R.id.distanceText).text = String.format(Locale.getDefault(), "%.2f km", distance(todays))
    }

    private fun distance(list: List<Stop>): Double {
        var sum = 0.0
        for (i in 1 until list.size) {
            val a = list[i - 1]; val b = list[i]
            val r = 6371.0
            val dLat = Math.toRadians(b.lat - a.lat)
            val dLon = Math.toRadians(b.lon - a.lon)
            val x = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2.0)
            sum += 2 * r * asin(sqrt(x))
        }
        return sum
    }

    private fun dayKey(time: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(time))
    private fun saveStops() {
        val arr = JSONArray()
        stops.forEach { s -> arr.put(JSONObject().put("lat", s.lat).put("lon", s.lon).put("note", s.note).put("time", s.time)) }
        prefs.edit().putString("stops", arr.toString()).apply()
    }
    private fun loadStops() {
        try {
            val arr = JSONArray(prefs.getString("stops", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                stops.add(Stop(o.getDouble("lat"), o.getDouble("lon"), o.optString("note"), o.getLong("time")))
            }
        } catch (_: Exception) { stops.clear() }
    }

    private fun showDailyReport() {
        val today = dayKey(System.currentTimeMillis())
        val list = stops.filter { dayKey(it.time) == today }
        val lines = list.mapIndexed { i, s ->
            "${i + 1}. ${if (s.note.isBlank()) "Location" else s.note} — ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(s.time))}"
        }
        val msg = "Date: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())}\nMarked places: ${list.size}\nTotal distance between marks: ${String.format(Locale.getDefault(), "%.2f km", distance(list))}\n\n${lines.joinToString("\n")}"
        AlertDialog.Builder(this).setTitle("Today's travel report").setMessage(msg).setPositiveButton("Close", null).show()
    }

    private fun showHistory() {
        val grouped = stops.groupBy { dayKey(it.time) }.toSortedMap(compareByDescending { it })
        val msg = if (grouped.isEmpty()) "No journeys saved yet." else grouped.entries.joinToString("\n\n") { (day, list) ->
            "$day — ${String.format(Locale.getDefault(), "%.2f km", distance(list))} · ${list.size} places"
        }
        val monthly = stops.groupBy { it.time.let { t -> SimpleDateFormat("yyyy-MM", Locale.US).format(Date(t)) } }
            .toSortedMap(compareByDescending { it })
        val monthlyText = monthly.entries.joinToString("\n") { (month, list) -> "$month: ${String.format(Locale.getDefault(), "%.2f km", distance(list))}" }
        AlertDialog.Builder(this).setTitle("Journey history & monthly summary")
            .setMessage("$msg\n\nMONTHLY TOTALS\n$monthlyText").setPositiveButton("Close", null).show()
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause() }
}
